$("#inputNumber, #number").mask("+00 (00) 00000-0000");
